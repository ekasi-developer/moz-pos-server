<?php

namespace Bluteki\MPesa\Tests;

use Orchestra\Testbench\TestCase as BaseTestCase;

class TestCase extends BaseTestCase
{
    use CreatePackage;
}