<?php

namespace Bluteki\MPesa\Exceptions;

use Exception;

class InvalidEnvironmentException extends Exception
{
}